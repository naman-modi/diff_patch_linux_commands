# DSA_Implementing_Diff_and_Patch_Linux_Commands

Naman Modi
SY IT 
111708037

In this project, I have implemented the diff and patch linux commands, and the attributes -c -w  -b -i of diff. In patch I have considered patching
through -c output of diff as well as normal output of diff.
My ./project1 is for diff operation.
My ./project2 is for patch operation.
